import React, { Component } from 'react';
import SwapiService from '../../services/swap-service';
import Spinner from '../spinner'
import './item-list.css'

export default class ItemList extends Component{
    swapiService = new SwapiService();

    state = {
        planetList:null,
 
    }
    componentDidMount(){
        this.swapiService.getAllPlanets()
        .then((planetList)=>{
            this.setState({planetList})
        })

    }    
        renderItem=(arr)=>{
            return arr.map(({id,name})=>{
                
                    return(
                        <li className="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
                            key = {id}
                            onClick={()=> this.props.onItemSelected(id)}
                        >
                            {name}
                        </li>
                    )
                })
        }

    render(){
        const{planetList} = this.state;
        if(!planetList){
            return <Spinner/>;
        }
        const itemList = this.renderItem(planetList);
        return(
            <ul className="list-group">
                {/* <li className="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                    Luke Skywalker
                </li>
                <li className="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                   Dart Vader
                </li>
                <li className="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                    R2-D2
                </li> */}
                {itemList}
            </ul>
        )
    }
}
