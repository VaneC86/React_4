import React from 'react';
import './spinner.css'



const Spinner = () =>{
    return (
        <div className='d-flex justify-content-center'>
        <div className="loader">Loading...</div>
        </div>
    )
}
export default Spinner;