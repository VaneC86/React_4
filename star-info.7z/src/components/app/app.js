// import React from 'react';
// import './app.css';

// import PlanetRandom from '../planet-random'

// //import HeaderApp

// const App = () => {
//     return (
//         <div className='container'>
//             {/*header*/}
//             {/*random planet*/}
//             <PlanetRandom />
//             <div className='row'>
//                 <div className='col-6'>
//                     {/*item list*/}
//                 </div>
//                 <div className='col-6'>
//                     {/*persone details*/}
//                 </div>
//             </div>
//         </div>
//     )
// }

// export default App;


// import React from 'react';
import React, { Component } from 'react';
import './app.css';

import Header from '../header'
import PlanetRandom from '../planet-random'
import ItemList from '../item-list'
import PeopleDetail from '../people-detail'
import PlanetDetail from '../planet-detail'
import StarshipDetail from '../starship-detail'
import ErrorButton from '../error-button';
import ErrorIndicator from '../error-indicator';

//import HeaderApp
export default class App extends Component{


state ={
    selectedPlanet:2,
    hasError:false


}
onItemSelected = (id)=>{
    this.setState({
        selectedPlanet:id
    });

}
componentDidCatch(){
    this.setState({
        hasError:true
    })
}

render(){
    if(this.state.hasError){
        return <ErrorIndicator/>
    }

    return (
        <div className='container'>
            <Header onTooglePage={this.onTooglePage}/>  
            <PlanetRandom />
            <ErrorButton/>
          
            <div className='row'>
                <div className='col-6'>
                    {/*item list*/}
                    <ItemList onItemSelected={this.onItemSelected}/>
                </div>
                <div className='col-6'>
                    {/*persone details*/}
              
                    <PlanetDetail planetId={this.state.selectedPlanet}/>
                    {/*<StarshipDetail />*/}
                    
                </div>
            </div>
        </div>
    )
}
}

//
/*switch (name){
    case 'people':{
        this.swapiService.getAllPeople()
        then((data)=>{
            this.setState({data})
        })
        this.detail = <PeopleDetail planetId={this.state.SelectedPlanet}/>;
        return this.state.data
    }

    case 'planet':{
        this.swapiService.getAllPlanets()
        then((data)=>{
            this.setState({data})
        })
        this.detail = <PlanetDetail planetId={this.state.SelectedPlanet}/>;
        return this.state.data
    }

        case 'starship':{
        this.swapiService.getAllStarships()
        then((data)=>{
            this.setState({data})
        })
        this.detail = <StarshipDetail planetId={this.state.SelectedPlanet}/>;
        return this.state.data
    }
}
*/