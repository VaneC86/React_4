import PeopleDetail from './people-detail'

export default PeopleDetail;