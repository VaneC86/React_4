import React, { Component } from 'react';

import './planet-detail.css'
import ErrorButton from '../error-button';
import ErrorIndicator from '../error-indicator';
import SwapiService from '../../services/swap-service';


export default class PlanetDetail extends Component{
    swapiService = new SwapiService();
    state = {
        planet:[],
        hasError:false
    }

    componentDidMount(){
        this.updatePlanet();
    }

    componentDidUpdate(prevProps){
        if(this.props.planetId !==prevProps.planetId){
            this.updatePlanet();
        }
    }
    componentDidCatch(){
        this.setState({hasError:true})
    }
    updatePlanet=()=>{
    const{planetId} = this.props;
    console.log(planetId)
    if(!planetId){
        return
    }

         this.swapiService.getPlanet(planetId)
        .then((planet)=>{
            this.setState({planet})
        })
    }

    render(){
        if(this.state.hasError){
            return <ErrorIndicator/>
        }
        const {name,id,population,diameter,rotationPeriod,gravity} = this.state.planet
        return(
            <div className='planet-detail jumbotron rounded'>
                <img 
                    src={'https://starwars-visualguide.com/assets/img/planets/'+id+'.jpg'}
                    className='planet-image'
                />
                <div>
                    <h4>{name}</h4>
                    <ul className="list-group">
                        <li className="list-group-item">
                            <span className='tern'>Population:</span>
                            <span>{population}</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Rotation Period:</span>
                            <span>{rotationPeriod}</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Orbital Period:</span>
                            <span>364 days</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Diameter:</span>
                            <span>{diameter}</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Gravity:</span>
                            <span>{gravity}</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Terrain:</span>
                            <span>Grasslands, Mountains</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Surface Water:</span>
                            <span>40%</span>
                        </li>
                        <li className="list-group-item">
                            <span className='tern'>Climate:</span>
                            <span>Temperate</span>
                        </li>
                    </ul>
                    <ErrorButton/>
                </div>
            </div>
        )
    } 
}