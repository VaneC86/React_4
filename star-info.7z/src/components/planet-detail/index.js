import PlanetDetail from './planet-detail'

export default PlanetDetail;
