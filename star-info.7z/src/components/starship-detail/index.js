import StarshipDetail from './starship-detail'

export default StarshipDetail;