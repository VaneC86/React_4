import PlanetRandom from './planet-random'

export default PlanetRandom;